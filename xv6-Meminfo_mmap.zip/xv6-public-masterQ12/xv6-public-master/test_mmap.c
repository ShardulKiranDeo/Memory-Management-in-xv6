#include "types.h"
#include "stat.h"
#include "user.h"

int main() {
    printf(1, "Initial numvp: %d\n", numvp());
    printf(1, "Initial numpp: %d\n", numpp());
    void *addr = (void *)mmap(8192); 
    if (addr == 0) {
        printf(1, "mmap failed\n");
        exit();
    }
    printf(1, "After mmap numvp: %d\n", numvp());
    printf(1, "After mmap numpp: %d\n", numpp());

    
    ((char *)addr)[0] = 'A';
    ((char *)addr)[4096] = 'B';
    printf(1, "After access numvp: %d\n", numvp());
    printf(1, "After access numpp: %d\n", numpp());

    exit();
}
