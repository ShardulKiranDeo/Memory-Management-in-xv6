#include "types.h"
#include "stat.h"
#include "user.h"

int main() {
    printf(1, "numvp: %d\n", numvp());
    printf(1, "numpp: %d\n", numpp());

    exit();
}
